-- Script de creacion de tablas del sistema de Prestamos de Biblioteca.
-- Se ejecuta automaticamente cada vez que arranca el programa
-- (InicializadorBaseDatos.Inicializar). Usa IF NOT EXISTS, asi que es
-- seguro ejecutarlo mas de una vez sin borrar datos existentes.

CREATE TABLE IF NOT EXISTS Lectores (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Codigo TEXT NOT NULL UNIQUE,
    Nombre TEXT NOT NULL,
    Correo TEXT NOT NULL,
    Telefono TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Libros (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Codigo TEXT NOT NULL UNIQUE,
    Titulo TEXT NOT NULL,
    Autor TEXT NOT NULL,
    Ejemplares INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS Prestamos (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    LectorId INTEGER NOT NULL,
    LibroId INTEGER NOT NULL,
    FechaPrestamo TEXT NOT NULL,
    FechaLimite TEXT NOT NULL,
    FechaDevolucion TEXT,
    FOREIGN KEY (LectorId) REFERENCES Lectores(Id),
    FOREIGN KEY (LibroId) REFERENCES Libros(Id)
);
